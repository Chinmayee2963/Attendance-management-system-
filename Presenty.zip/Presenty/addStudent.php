<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Information Form</title>

<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
  }

  .container {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  h2 {
    text-align: center;
  }

  form {
    margin-top: 20px;
  }

  label {
    font-weight: bold;
  }

  input[type="text"] {
    width: 100%;
    padding: 10px;
    margin: 5px 0 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    font-size: 16px;
  }

  input[type="submit"]:hover {
    background-color: #45a049;
  }

  input:invalid {
    border-color: #ff6347;
  }
</style>

</head>
<body>

<div class="container">
  <h2>Admin Information Form</h2>
  <form method="post">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>

    <label for="GRN_No">GRN no:</label><br>
    <input type="text" id="GRN_No" name="GRN_No" required><br><br>

    <label for="class">class:</label><br>
    <input type="text" id="class" name="class" required><br><br>

    <label for="div">Div:</label><br>
    <input type="text" id="div" name="div" required><br><br>

    <label for="rollNo">Roll Number:</label><br>
    <input type="text" id="rollNo" name="rollNo" required><br><br>

    <input type="submit" value="Submit">
  </form>
</div>

</body>
</html>

<?php
 $conn= new mysqli("localhost","root","","attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
$name = $_POST['name'];
$username =$_POST['GRN_No'];
$class= $_POST['class'];
$div = $_POST['div'];
$rollNo = $_POST['rollNo'];
$password=$_POST['pass'];


if(($class=='ty' || $class=="TY" ||$class=="Third Year") && ($div=='a'||$div=='A'))
{
  $table='ty_a';
}elseif(($class=='ty'|| $class=="TY" ||$class=="Third Year" )&&( $div=='b'||$div=='B'))
{
  $table='ty_b';
}elseif(($class=='ty'|| $class=="TY" ||$class=="Third Year") && ($div=='c'||$div=='C'))
{
  $table='ty_c';
}else
{
  echo "invalid class";
  exit();
}



$sql = "insert into $table values('$name','$class', '$div', '$rollNo' ,'$username','$password')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}


$conn->close();
?>
