<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="class.css">
    <title></title>
    <style>
       /* body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            justify-content: center;
        }

        button {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
        }

        button:hover {
            background-color: #0056b3;
        }*/
    </style>
</head>
<body>
    <div class="container"> 
    <form action="division.php" method="post">
        <button type="submit" name="FY">FY</button>
        <button type="submit" name="SY">SY</button>
        <button type="submit" name="TY">TY</button>
    </form>
    </div>
</body>
</html>
