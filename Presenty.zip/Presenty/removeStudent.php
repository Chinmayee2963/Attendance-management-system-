<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Record Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
  }

  form {
    max-width: 400px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  label {
    display: block;
    margin-bottom: 10px;
    font-weight: bold;
  }

  input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
  }

  input[type="submit"]:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<form method="post">
 
  <label for="class">Class:</label><br>
  <input type="text" id="class" name="class" required><br><br>

  <label for="div">Div:</label><br>
  <input type="text" id="div" name="div" required><br><br>

  <label for="GRN_No">GRN No:</label><br>
  <input type="text" id="GRN_No" name="GRN_No" required><br><br>
  
  <input type="submit" value="Submit">

</form>



<?php
$conn= new mysqli("localhost","root","","attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
$GRN = $_POST['GRN_No'];
$class = $_POST['class'];
$div = $_POST['div'];

if ($class == 'ty' && $div == 'a') {
  $table = 'ty_a';
} elseif ($class == 'ty' && $div == 'b') {
  $table = 'ty_b';
} elseif ($class == 'ty' && $div == 'c') {
  $table = 'ty_c';
} else {
  echo "Invalid class";
  exit();
}

$sql = "DELETE FROM $table WHERE GRN_No = $GRN";


if ($conn->query($sql) === TRUE) {
   echo '<script>alert("Record Deleted Successfully");</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>

</body>
</html>
