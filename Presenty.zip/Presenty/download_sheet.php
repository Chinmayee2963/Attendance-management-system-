

<?php
      $con= new mysqli("localhost","root","","attendance_system");
 	if ($con->connect_error) 
 	{
        die("Connection failed: " . $con->connect_error);
    }

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
    	if(isset($_POST["A"]))
	    		{
		    		 $sql="select rollNo, username, name from ty_a";
			    	 $result = $conn->query($sql);

						// Generate CSV file content
						$csv_content = "Name, Roll No., Attendance Status\n";
						if ($result->num_rows > 0) 
						{
						    while($row = $result->fetch_assoc()) 
						    {
						        $csv_content .= $row["name"] . ", " . $row["rollNo"] . ", "  . "\n";
						    }
						}

						// Download CSV file
						header('Content-Type: application/csv');
						header('Content-Disposition: attachment; filename="attendance_sheet.csv"');
						echo $csv_content;
			   	}
			   	if(isset($_POST["B"]))
		    	{
			    		$sql="select rollNo, username, name from ty_b";
				    	 $result = $conn->query($sql);

							// Generate CSV file content
							$csv_content = "Name, Roll No., Attendance Status\n";
							if ($result->num_rows > 0) 
							{
							    while($row = $result->fetch_assoc()) 
							    {
							        $csv_content .= $row["name"] . ", " . $row["rollNo"] . ", "  . "\n";
							    }
							}

							// Download CSV file
							header('Content-Type: application/csv');
							header('Content-Disposition: attachment; filename="attendance_sheet.csv"');
							echo $csv_content;

		   		}


		   		if(isset($_POST["C"]))
	    		{
	    			$sql="select *from ty_c";
		    	 /*$data= $con->query($con, $sql);
		    	 $total=mysqli_num_rows($data);
		    	 //$reslut=mysqli_fetch_assco($data);

		    	 if($total!=0)
		    	 {
		    	 	while($result= mysqli_fetch_assco($sql))
		    	 	{
		    	 		echo var_dump($result);
		    	 		echo "<br>";
		    	 		//echo $reslut[rollNo]. " ".$result[username]." ".$result[name]." "."<br>";
		    	 	}
		    	 }*/
		    	 $result = $conn->query($sql);

							// Generate CSV file content
							$csv_content = "Name, Roll No., Attendance Status\n";
							if ($result->num_rows > 0) 
							{
							    while($row = $result->fetch_assoc()) 
							    {
							        $csv_content .= $row["name"] . ", " . $row["rollNo"] . ", "  . "\n";
							    }
							}

							// Download CSV file
							header('Content-Type: application/csv');
							header('Content-Disposition: attachment; filename="attendance_sheet.csv"');
							echo $csv_content;
												    
					} 
					
		    	
		    }
    
		    	 
	    else
	    {
	    	echo "0 result";
	    }
	    echo "</table>";
	   
    

   
    
    $con->close();


   ?>