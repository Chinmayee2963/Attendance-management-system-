<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="login-container">
        
        <form class="login-form" action="login.php" method="post" onsubmit="return redirectToNextPage()">
            
            <input type="text" name="year" placeholder="Year" required><br>
            <input type="text" name="div" placeholder="Division" required><br>
            <input type="submit" name="save" value="Login">
        </form>

    </div>
</body>
</html>

 <?php
       $con= new mysqli("localhost","root","","attendance_system");
 	if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    
		$username=$_POST['username'];
       	$password=$_POST['password'];
       	$table=$_POST['div'];
		$sql="select *from ty_$table where username='$username' and password='$password'";
		$result= $con->query($sql);
		if($result->num_rows>0)  //student info block
	    {
	    	echo "Student log in succesfully";
	    	echo "\n";
	    	echo "Student Name: $username";
	    	echo "\n";
	    	echo "password: $password";
	    }
	    	
	    else 
	    {
	    	echo "unsuccessfully";
	    }
 ?>