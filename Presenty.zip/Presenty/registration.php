<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registration Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
  }
  .container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
  }
  .form-group {
    margin-bottom: 20px;
  }
  .form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
  }
  .form-group input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  .form-group select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  .form-group button {
    padding: 10px 20px;
    background-color: #4caf50;
    border: none;
    color: white;
    border-radius: 5px;
    cursor: pointer;
  }
</style>
</head>
<body>
<div class="container">
  <h2>Registration Form</h2>
  <form action="registration.php" method="post">
    <div class="form-group">
      <label for="type">User Type:</label>
      <select name="type" id="type" onchange="showFields()">
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
    </div>
    <div class="form-group" id="name-group">
      <label for="name">Name:</label>
      <input type="text" name="name" id="name" required>
    </div>
    
    <div class="form-group" id="subject-group" style="display: none;">
      <label for="subject">Subject:</label>
      <input type="text" name="subject" id="subject">
    </div>
    <div class="form-group" id="class-group">
      <label for="class">Class:</label>
      <select name="class" id="class" required>
        <option value="FY">FY</option>
        <option value="SY">SY</option>
        <option value="TY">TY</option>
      </select>
    </div>
    <div class="form-group" id="division-group">
      <label for="division">Division:</label>
      <select name="division" id="division" required>
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="C">C</option>
      </select>
    </div>
    <div class="form-group" id="grn-group">
      <label for="username">UserId:</label>
      <input type="text" name="username" id="username">
    </div>
    <div class="form-group" id="rollno-group">
      <label for="rollno">Roll No:</label>
      <input type="text" name="rollno" id="rollno">
    </div>
    <div class="form-group" id="password-group">
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" required>
    </div>


	<div class="form-group" id="phoneNo-group">
      <label for="phoneNo">Phone No:</label>
      <input type="text" name="phoneNo" id="phoneNo" required>
    </div>

    <div class="form-group" id="subject-group">
      <label for="subject">Subject:</label>
      <input type="text" name="subject" id="subject" required>
    </div>    

    <div class="form-group" id="education-group">
      <label for="education">Education:</label>
      <input type="text" name="education" id="education" required>
    </div>



    <button type="submit">Register</button>

  </form>
  
  <a href="login.html">
    <button type="submit">Log in</button>
    </a>
    
</div>

<script>
  function showFields() {
    var userType = document.getElementById('type').value;
    var classGroup = document.getElementById('class-group');
    var divisionGroup = document.getElementById('division-group');
    var grnGroup = document.getElementById('grn-group');
    var rollNoGroup = document.getElementById('rollno-group');
    var nameGroup = document.getElementById('name-group');
    var userIdGroup = document.getElementById('userid-group');
    var passwordGroup = document.getElementById('password-group');
    var subjectGroup = document.getElementById('subject-group');
     var phoneNoGroup = document.getElementById('phoneNo-group');
      var educationGroup = document.getElementById('education-group');

    if (userType === 'student') {
      classGroup.style.display = 'block';
      divisionGroup.style.display = 'block';
      grnGroup.style.display = 'block';
      rollNoGroup.style.display = 'block';
      nameGroup.style.display = 'block';
      userIdGroup.style.display = 'none';
      passwordGroup.style.display = 'block';
      subjectGroup.style.display = 'none';
    } else if (userType === 'teacher') {
      classGroup.style.display = 'none';
      divisionGroup.style.display = 'none';
      grnGroup.style.display = 'block';
      rollNoGroup.style.display = 'none';
      nameGroup.style.display = 'block';
      userIdGroup.style.display = 'block';
      passwordGroup.style.display = 'block';
      subjectGroup.style.display = 'block';
      educationGroup.style.display='block';
      phoneNoGroup.style.display='block';
    }
  }
</script>
</body>
</html>



<?php
try{
$conn= new mysqli("localhost","root","","attendance_system");
 	if ($conn->connect_error) 
 	{
        die("Connection failed: " . $con->connect_error);
    }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userType = $_POST["type"]; 
    
    if ($userType === "student") {

    	$username=$_POST['username'];
    	$password=$_POST['password'];
    
      $query="select *from ty_a WHERE username ='$username' and password='$password'
            UNION 
            select *from ty_b WHERE username ='$username' and password='$password'
            UNION 
            select *from ty_c WHERE username ='$username' and password='$password' ";

      $result=$conn->query($query);

      if($result->num_rows>0)
      {
        echo '<script>alert("already registered");</script>';
       }


    	$name = $_POST["name"];
    	$password = $_POST["password"];
        $grn = $_POST["username"];
        $class = $_POST["class"];
        $division = $_POST["division"];
        $rollNo = $_POST["rollno"];
        
        if($class==='TY' && $division==='A')
        {
        		$sql = "INSERT INTO ty_a VALUES ('$name', '$class','$division','$rollNo','$grn','$password')";
        }
        else if($class==='TY' && $division==='B')
        {
        		$sql = "INSERT INTO ty_b VALUES ('$name', '$class','$division','$rollNo','$grn','$password')";
        }
        else if($class==='TY' && $division==='C')
        {
        		$sql = "INSERT INTO ty_c  VALUES ( '$name', '$class','$division','$rollNo','$grn','$password' )";
        }
        else
        {
        	echo "user is already registered";
        }




    } else if ($userType === "teacher") {

    	$username=$_POST['username'];
    	$password=$_POST['password'];
    
      $query="select *from teacher WHERE username ='$username' and password='$password'";

      $result=$conn->query($query);

      if($result->num_rows>0)
      {
        echo '<script>alert("already registered");</script>';
       }


    	$name = $_POST["name"];
    	$userid = $_POST["username"];
    	$password = $_POST["password"];
        $subject = $_POST["subject"];
        $phoneNo= $_POST["phoneNo"];
        $education=$_POST["education"];
        
        // Insert teacher data into the database
        $sql = "INSERT INTO teacher VALUES ('$name', '$userid', '$password', '$phoneNo','$subject','$education')";
    }
    
if ($conn->query( $sql ) === TRUE) {
   echo '<script>alert("Registered Successfully");</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
}
catch(Exception $e)
{
	echo "Error occured";
}
$conn->close();
?>





