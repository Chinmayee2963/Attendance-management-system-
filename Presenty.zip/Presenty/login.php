<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstram.min.css">
    <title></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 80%;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>
    <table>
        
    <?php
       $con= new mysqli("localhost","root","","attendance_system");
  if ($con->connect_error) 
  {
        die("Connection failed: " . $con->connect_error);
  }
      
    $username=$_POST['username'];
    $password=$_POST['password'];
    
      $query="select *from ty_a WHERE username ='$username' and password='$password'
            UNION 
            select *from ty_b WHERE username ='$username' and password='$password'
            UNION 
            select *from ty_c WHERE username ='$username' and password='$password' ";

      $result=$con->query($query);

      if($result->num_rows>0)
      {
        echo '<script>alert("Login Successfully");</script>';
        while($row=$result->fetch_assoc())
        {
          echo "Name: ".$row["name"]."<br>";
          echo "GRN No: ".$row["username"]."<br>";
          echo "ROll No: ".$row["rollNo"]."<br>";
          echo "Class: ".$row["class"]."<br>";
          echo "Division: ".$row["division"]."<br>";
          //echo "Monthly presenty percentage: ".$row["name"]."<br>";


        }
        //header("Location= student.php");
      }
      else 
      {
        $query="select *from teacher WHERE username ='$username' and password='$password'";
        $result=$con->query($query);
        if($result->num_rows>0)
        {
          header("Location: class.php");
          echo '<script>alert("Login Successfully");</script>';
        }
        else
        {
           $query="select *from admin WHERE username ='$username' and password='$password'";
            $result=$con->query($query);
            if($result->num_rows>0)
            {
              header("Location: adminOperation.php");
              echo '<script>alert("Login Successfully");</script>';
              
            }
            else
            {
              echo '<script>alert("Login Unsuccessfully");</script>';
            }
        }

      }
    

    
  
    $con->close();
   ?>
    </table>
</body>
</html>
