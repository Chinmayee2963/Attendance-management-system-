<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstram.min.css">
    <title>Database Table</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <table>

        
    <?php

       $con= new mysqli("localhost","root","","attendance_system");
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
        
    $sql="select name,rollNo, class,division, username from ty"

   ?>
   </table>
</body>

</html>

