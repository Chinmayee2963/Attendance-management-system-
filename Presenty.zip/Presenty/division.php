<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="division.css">
</head>
<body>
	<div class="container">
	<form action="attendance.php" method="post" >
	<button type="submit" name="A" >A</button>
	<button type="submit" name="B" >B</button>
	<button type="submit" name="C" >C</button>
	</form>
	</div>
	


 
</body>
</html>

