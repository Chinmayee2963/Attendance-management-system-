<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style>
        button {
            display: block;
            margin: 10px auto;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <form method="post">
        <button type="submit" name="nextPage" value="addTeacher">Add Teacher</button>
        <button type="submit" name="nextPage" value="addStudent">Add Student</button>
        <button type="submit" name="nextPage" value="removeTeacher">Remove Teacher</button>
        <button type="submit" name="nextPage" value="removeStudent">Remove Student</button>
        <button type="submit" name="nextPage" value="DefaulterList">Defaulter List</button>
    </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['nextPage'])) {

        $page = $_POST['nextPage'];

        if ($page === "addTeacher") {
            header("Location: addTeacher.php");
        } elseif ($page === "addStudent") {
            header("Location: addStudent.php");
        } elseif ($page === "removeTeacher") {
            header("Location: removeTeacher.php");
        } elseif ($page === "removeStudent") {
            header("Location: removeStudent.php");
        } elseif ($page == "DefaulterList") {
            header("Location: DefaulterList.php");
        } else {
            echo " ";
        }
    }
}
?>
