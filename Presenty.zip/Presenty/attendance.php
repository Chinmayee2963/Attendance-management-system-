<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="attendance.css	">
</head>
<body>
	<select name="subject" id="subject">
  <option value="lecture">Lecture</option>
  <option value="lab">Lab</option>
</select>


	<select name="subject" id="subject">
  <option value="stqa">Software Testing and Quality Assurance</option>
  <option value="aca">Advanced Computer Archetecture</option>
  <option value="ml">Machine Learning</option>
  <option value="iot">Internet of Things</option>
  <option value="java">Java Programming</option>
  <option value="db">Database Engineering</option>

  <!-- Add more options as needed -->
</select>

<?php
$currentDate = date("Y-m-d");
echo "date:".$currentDate;

?>
	<table>
	<tr>
			<th>Id     </th>
			<th>GRN No   </th>
			<th>  Name  </th>
		</tr>
	


<?php
      $con= new mysqli("localhost","root","","attendance_system");
 	if ($con->connect_error) 
 	{
        die("Connection failed: " . $con->connect_error);
    }

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
    	if(isset($_POST["A"]))
	    		{
		    		 $sql="select rollNo, username, name from ty_a";
			    	 $result= $con->query($sql);
			    	 if($result->num_rows>0)
			   		{
			   			echo "<table>";

				    	while ($row=$result->fetch_assoc())
				    	{
				    		echo "<td>".$row["rollNo"]."</td>";
				    		echo "<td>".$row["username"]."</td>";
				    		echo "<td>".$row["name"]."</td>";
				    	}
				    	echo "</table>";
				    }

			   	}
			   	if(isset($_POST["B"]))
		    	{
			    		$sql="select rollNo, username, name from ty_b";
				    	 $result= $con->query($sql);
				    	 if($result->num_rows>0)
				   		{

					    	while($row=$result->fetch_assoc())
					    	{
					    		echo "<tr> <td>".$row["rollNo"]."</td> <td>".$row["username"]."</td> <td>".$row["name"]."</td></tr>";
					    	}
					    	echo "</table>";
					    }

		   		}


		   		if(isset($_POST["C"]))
	    		{
	    			$sql="select *from ty_c";
		    	 /*$data= $con->query($con, $sql);
		    	 $total=mysqli_num_rows($data);
		    	 //$reslut=mysqli_fetch_assco($data);

		    	 if($total!=0)
		    	 {
		    	 	while($result= mysqli_fetch_assco($sql))
		    	 	{
		    	 		echo var_dump($result);
		    	 		echo "<br>";
		    	 		//echo $reslut[rollNo]. " ".$result[username]." ".$result[name]." "."<br>";
		    	 	}
		    	 }*/
		    	 $result= $con->query($sql);
			    	 //$sql = "SELECT name, rollNo FROM student";
					//$result = $conn->query($sql);

					if ($result->num_rows > 0)
					 {
					    // Output data of each row
					    while($row = $result->fetch_assoc())
					     {
					        echo "<tr>";
					        
					        echo "<td>"  .$row["rollNo"] . "</td>";
					        echo "<td>". $row["username"]."</td>";
					        echo "<td>".$row["name"] . "</td>";


					        echo "<td><input type='checkbox' name='attendance[]' value='" . $row["rollNo"] . "'></td>";
					        echo "</tr>";
					    }
					} 
					
					
		    	}
		    }
    
		    	 
	    else
	    {
	    	echo "0 result";
	    }
	    echo "</table>";
	   
    

   
    
    $con->close();


   ?>


</table>
<input type="submit" value="Save Attendance">
</form>

<form action="download_sheet.php" method="post">
  <input type="submit" value="Download Attendance Sheet">
</form>


   </body>
</html>