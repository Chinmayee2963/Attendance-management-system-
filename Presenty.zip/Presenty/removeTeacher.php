<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ID Number Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
  }

  form {
    max-width: 400px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  label {
    display: block;
    margin-bottom: 10px;
    font-weight: bold;
  }

  input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
  }

  input[type="submit"]:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<form method="post">
  <label for="id">User id:</label><br>
  <input type="text" id="uid" name="uid" required><br><br>
  <input type="submit" value="Submit">
</form>

</body>
</html>

<?php
try{
$conn= new mysqli("localhost","root","","attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
$user=$_POST["uid"];

$sql = "DELETE FROM teacher WHERE username = '$user'";




if ($conn->query($sql) === TRUE) {
   echo "Record Deleted Successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
}
catch (Exception $e)
{
  echo "Error occured";
}

$conn->close();
?>
